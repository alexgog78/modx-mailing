<?php

require_once(dirname(__DIR__) . '/mailinglog.class.php');

class mailingLog_mysql extends mailingLog
{
}
