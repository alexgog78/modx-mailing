<?php

require_once MODX_CORE_PATH . 'model/modx/mail/modphpmailer.class.php';

class mailingMailer extends modPHPMailer
{
}
