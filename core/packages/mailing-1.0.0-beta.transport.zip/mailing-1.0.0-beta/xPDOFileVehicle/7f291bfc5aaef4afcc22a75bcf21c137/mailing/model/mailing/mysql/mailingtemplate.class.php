<?php

require_once(dirname(__DIR__) . '/mailingtemplate.class.php');

class mailingTemplate_mysql extends mailingTemplate
{
}
