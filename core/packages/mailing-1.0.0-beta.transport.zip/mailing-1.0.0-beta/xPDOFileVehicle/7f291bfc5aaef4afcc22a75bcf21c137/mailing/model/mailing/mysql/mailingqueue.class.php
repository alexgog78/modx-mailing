<?php

require_once(dirname(__DIR__) . '/mailingqueue.class.php');

class mailingQueue_mysql extends mailingQueue
{
}
