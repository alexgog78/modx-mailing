<?php

$xpdo_meta_map = [
    'xPDOSimpleObject' => [
        0 => 'mailingTemplate',
        1 => 'mailingQueue',
        2 => 'mailingLog',
    ],
];
