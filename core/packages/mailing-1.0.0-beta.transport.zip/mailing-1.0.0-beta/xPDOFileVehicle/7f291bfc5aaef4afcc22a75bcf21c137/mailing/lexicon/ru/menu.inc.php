<?php

$prefix = 'mailing_menu_';

$_lang[$prefix . 'templates'] = 'Шаблоны рассылки';
$_lang[$prefix . 'templates_desc'] = 'Создание рассылок для пользователей';
$_lang[$prefix . 'queues'] = 'Очередь рассылки';
$_lang[$prefix . 'queues_desc'] = 'Очередь пользователей для рассылки';
$_lang[$prefix . 'logs'] = 'Логи рассылок';
$_lang[$prefix . 'logs_desc'] = 'Логи отправки рассылок';
