<?php

$prefix = 'mailing';

$_lang[$prefix] = 'Mailing';
$_lang[$prefix . '_desc'] = 'Массовая Email рассылка';
$_lang[$prefix . '_undefined'] = '<span class="icon icon-lock" style="font-size: 200%;"></span><br />Для начала сохраните объект';
$_lang[$prefix . '_indevelopment'] = '<span class="icon icon-cog" style="font-size: 200%;"></span><br />Раздел находится в разработке';

include_once __DIR__ . '/menu.inc.php';
