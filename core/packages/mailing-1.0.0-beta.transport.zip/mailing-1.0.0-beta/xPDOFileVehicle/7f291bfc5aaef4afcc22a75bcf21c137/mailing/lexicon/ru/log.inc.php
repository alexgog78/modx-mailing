<?php

$prefix = 'mailing_log_';

$_lang[$prefix . 'list'] = 'Логи рассылок';
$_lang[$prefix . 'list_management'] = 'Здесь находятся логи рассылок.';

$_lang[$prefix . 'queue'] = 'ID очереди';
$_lang[$prefix . 'template'] = 'Шаблон';
$_lang[$prefix . 'status'] = 'Статус';
$_lang[$prefix . 'createdon'] = 'Дата создания';
$_lang[$prefix . 'createdby'] = 'Создано';
$_lang[$prefix . 'updatedon'] = 'Дата изменения';
$_lang[$prefix . 'updatedby'] = 'Изменено';
