<?php

$prefix = 'mailing_queue_';

$_lang[$prefix . 'list'] = 'Очередь рассылки';
$_lang[$prefix . 'list_management'] = 'Здесь находятся пользователи в очереди на рассылку.';
$_lang[$prefix . 'process'] = 'Отправить письмо';
$_lang[$prefix . 'process_confirm'] = 'Вы уверены, что хотите отправить это письмо?';
$_lang[$prefix . 'process_all'] = 'Разослать письма';
$_lang[$prefix . 'process_all_confirm'] = 'Вы уверены, что хотите отправить все письма?';
$_lang[$prefix . 'clear_success'] = 'Удалить успешные записи';
$_lang[$prefix . 'clear_all'] = 'Очистить всю очередь';

$_lang[$prefix . 'status'] = 'Статус';
$_lang[$prefix . 'createdon'] = 'Дата создания';
$_lang[$prefix . 'createdby'] = 'Создано';
$_lang[$prefix . 'updatedon'] = 'Дата изменения';
$_lang[$prefix . 'updatedby'] = 'Изменено';
