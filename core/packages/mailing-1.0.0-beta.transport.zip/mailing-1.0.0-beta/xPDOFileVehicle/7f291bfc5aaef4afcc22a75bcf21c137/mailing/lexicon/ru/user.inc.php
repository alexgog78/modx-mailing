<?php

$prefix = 'mailing_user_';

$_lang[$prefix . 'group'] = 'Группа пользователей';
$_lang[$prefix . 'name'] = 'Имя получателя';
$_lang[$prefix . 'email'] = 'Email получателя';
$_lang[$prefix . 'count'] = 'Количество подписчиков';
