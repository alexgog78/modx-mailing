<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => 'Changelog for Mailing.
--------------------
¯\\_(ツ)_/¯
',
    'license' => '--------------------
Mailing
--------------------
Author: GrimWeb <a.goguev@alexgog.ru>
--------------------
',
    'readme' => 'Mailing
--------------------
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
¯\\_(ツ)_/¯¯\\_(ツ)_/¯¯\\_(ツ)_/¯
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cc213d0a7c9d1561a2da683c1851a46c',
      'native_key' => 'mailing',
      'filename' => 'modNamespace/bd96fd463ec4839d7e817fc0a5512db6.vehicle',
      'namespace' => 'mailing',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '6567af5c7dae8aafa52fad0c4b76a8e2',
      'native_key' => '6567af5c7dae8aafa52fad0c4b76a8e2',
      'filename' => 'xPDOFileVehicle/7f291bfc5aaef4afcc22a75bcf21c137.vehicle',
      'namespace' => 'mailing',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'a925534b414fd6863aefaea1f2c616bb',
      'native_key' => 'a925534b414fd6863aefaea1f2c616bb',
      'filename' => 'xPDOFileVehicle/6e67eed187033fe27099bb57432dc1b8.vehicle',
      'namespace' => 'mailing',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cdb3f707ea1da54ce47243633287e4f1',
      'native_key' => 'mailing',
      'filename' => 'modMenu/d66afbe6ca56209363abd42ca72e7351.vehicle',
      'namespace' => 'mailing',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '379facc4c93ec7a13660d09177c6de11',
      'native_key' => 'mailing_menu_templates',
      'filename' => 'modMenu/4d8ae9a7b883292dcdfb0eb4a8572f9a.vehicle',
      'namespace' => 'mailing',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e27d370b9e75c242bb2ee3a2670a1a24',
      'native_key' => 'mailing_menu_queues',
      'filename' => 'modMenu/3a07f7e42d8c2700832c63abb1be3666.vehicle',
      'namespace' => 'mailing',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '04fc560ba73b44824b855668f646421b',
      'native_key' => 'mailing_menu_logs',
      'filename' => 'modMenu/2018185d9d0edf942c0d9a58d3cff58b.vehicle',
      'namespace' => 'mailing',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef52b96ddb1c728ef422d223c1fd1886',
      'native_key' => 'mailingOnBeforeEmailSend',
      'filename' => 'modEvent/f31172953b403d3f72ef4893d1c6acfa.vehicle',
      'namespace' => 'mailing',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ee427849e2d6509a2aba1b15af683db',
      'native_key' => 'mailing_email_css',
      'filename' => 'modSystemSetting/8c2b1921b0a9ed168213a959518c44d4.vehicle',
      'namespace' => 'mailing',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b415b2708b955fc1ccbdb2ce22651e6',
      'native_key' => 'mailing_email_template',
      'filename' => 'modSystemSetting/4d277d5347af8fdcb4ef409b1ed1ed2c.vehicle',
      'namespace' => 'mailing',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abf3e81a2da50e4bc716587840b2907e',
      'native_key' => 'mailing_rate_limit',
      'filename' => 'modSystemSetting/448adcae1b616881e53706945782590b.vehicle',
      'namespace' => 'mailing',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08660174c5591090e48c142855a1fb38',
      'native_key' => 'mailing_rate_wait_time',
      'filename' => 'modSystemSetting/4fe82faeae3be773500a280c00052bfa.vehicle',
      'namespace' => 'mailing',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '1df7a8f17ca530504c5955019d78ee1a',
      'native_key' => '1df7a8f17ca530504c5955019d78ee1a',
      'filename' => 'xPDOScriptVehicle/cb8e374cf49be3271bd043db55b31424.vehicle',
      'namespace' => 'mailing',
    ),
  ),
);